import "./styles/global.css";
import "./styles/theme.css";
import Contador from "./components/Contador"

export default function App() {
  return (
    <div>
      <Contador />
    </div>
  );
}
